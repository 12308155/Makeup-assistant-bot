// DOM Elements
const chatMessages = document.getElementById('ai-chat-messages');
const userInput = document.getElementById('ai-user-input');
const sendMessageBtn = document.getElementById('ai-send-message');
const chatStatus = document.getElementById('chat-status');
const suggestionButtons = document.querySelectorAll('.suggestion-btn');
const clearChatBtn = document.querySelector('.feature-btn[title="Clear Chat"]');
const saveChatBtn = document.querySelector('.feature-btn[title="Save Chat"]');

// API Configuration
const API_KEY = 'AIzaSyAra_ol-J3Jt3zjmoL17ZUh6WmNghZ1lgE';
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

// Chat History
let chatHistory = [];

// Makeup and Beauty Related Keywords
const beautyKeywords = [
    'makeup', 'cosmetic', 'beauty', 'skin', 'face', 'hair', 'nail', 'lipstick', 'foundation',
    'concealer', 'powder', 'blush', 'bronzer', 'highlighter', 'eyeshadow', 'mascara', 'eyeliner',
    'brow', 'lip', 'gloss', 'contour', 'primer', 'setting spray', 'moisturizer', 'cleanser',
    'toner', 'serum', 'cream', 'lotion', 'sunscreen', 'acne', 'wrinkle', 'pore', 'dark circle',
    'spot', 'pigmentation', 'tone', 'complexion', 'oily', 'dry', 'combination', 'sensitive',
    'mature', 'young', 'anti-aging', 'hydration', 'exfoliate', 'mask', 'treatment', 'routine',
    'product', 'brand', 'natural', 'organic', 'chemical', 'ingredient', 'application', 'technique',
    'tutorial', 'tip', 'trick', 'hack', 'trend', 'style', 'look', 'glam', 'natural look',
    'evening look', 'bridal', 'party', 'everyday', 'waterproof', 'long-lasting', 'matte', 'dewy',
    'shimmery', 'metallic', 'nude', 'bold', 'dramatic', 'subtle', 'professional'
];

// Check if query is beauty-related
function isBeautyRelated(query) {
    query = query.toLowerCase();
    return beautyKeywords.some(keyword => query.includes(keyword.toLowerCase())) ||
           query.includes('how to') || query.includes('what is') || query.includes('recommend');
}

// Validate API key format
function isValidApiKey(key) {
    return key && key.startsWith('AIza') && key.length > 30;
}

// Update status with animation
function updateStatus(status, isError = false) {
    const statusElement = document.getElementById('chat-status');
    statusElement.textContent = status;
    statusElement.style.color = isError ? '#dc3545' : '#4CAF50';
    statusElement.style.opacity = '0';
    requestAnimationFrame(() => {
        statusElement.style.transition = 'opacity 0.3s ease';
        statusElement.style.opacity = '1';
    });
}

// Create and add message element
function addMessage(text, sender, isError = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}${isError ? ' error' : ''}`;
    
    if (sender === 'bot' && !isError) {
        // Format bot messages with structure
        const formattedText = formatBotResponse(text);
        messageDiv.innerHTML = formattedText;
    } else {
        const messageText = document.createElement('p');
        messageText.textContent = text;
        messageDiv.appendChild(messageText);
    }
    
    chatMessages.appendChild(messageDiv);
    
    // Ensure the new message is visible
    setTimeout(() => {
        messageDiv.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }, 100);

    // Store in chat history
    chatHistory.push({
        text,
        sender
    });
}

// Format bot responses
function formatBotResponse(text) {
    // Clean up the text first
    text = text.replace(/\*\*/g, ''); // Remove ** markers
    text = text.replace(/\s+/g, ' ').trim(); // Clean up extra spaces

    // Split into main sections
    const sections = text.split(/(?:\d+\.|Step [0-9]+:)/).filter(Boolean);
    let formattedHtml = '';

    if (sections.length > 1) {
        // If there are numbered sections, format as steps
        formattedHtml = '<div class="steps-container">';
        sections.forEach((section, index) => {
            if (section.trim()) {
                formattedHtml += `
                    <div class="step-item">
                        <div class="step-number">${index + 1}</div>
                        <div class="step-content">${section.trim()}</div>
                    </div>`;
            }
        });
        formattedHtml += '</div>';
    } else {
        // For regular responses without steps
        const paragraphs = text.split('\n').filter(Boolean);
        paragraphs.forEach(para => {
            if (para.toLowerCase().includes('tip:') || 
                para.toLowerCase().includes('note:') || 
                para.toLowerCase().includes('important:')) {
                formattedHtml += `<div class="key-point">${para.trim()}</div>`;
            } else {
                formattedHtml += `<p class="content-paragraph">${para.trim()}</p>`;
            }
        });
    }

    return formattedHtml;
}

// Create loading indicator
function createLoadingIndicator() {
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'message bot loading';
    loadingDiv.innerHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    return loadingDiv;
}

// Test API connection
async function testApiConnection() {
    try {
        updateStatus('Testing API connection...');
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-goog-api-key': API_KEY
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: "Test connection"
                    }]
                }]
            })
        });

        const data = await response.json();
        
        if (data.error) {
            console.error('API Error:', data.error);
            updateStatus('API Key Error: ' + data.error.message, true);
            return false;
}

        updateStatus('Ready to help');
        return true;
    } catch (error) {
        console.error('Connection Error:', error);
        updateStatus('Connection Error', true);
        return false;
    }
}

// Send message to AI
async function sendMessage(message) {
    if (!isValidApiKey(API_KEY)) {
        addMessage('Error: Invalid API key format. Please check your API key.', 'bot', true);
        updateStatus('Invalid API Key', true);
        return;
    }

    if (!isBeautyRelated(message)) {
        addMessage(message, 'user');
        addMessage("I'm your AI Makeup Assistant. Please ask me about makeup, skincare, or beauty-related topics!", 'bot');
        updateStatus('Ready to help');
        return;
    }

    try {
        addMessage(message, 'user');
        updateStatus('Processing...');

        const loadingDiv = createLoadingIndicator();
        chatMessages.appendChild(loadingDiv);

        const contextPrompt = `As an AI Makeup Assistant, provide a clear, step-by-step response about: ${message}. 
        Please format your response as follows:
        1. Start with a brief one-line introduction if needed
        2. Break down the answer into numbered steps
        3. Keep each step short and focused
        4. Add any important tips at the end
        5. Use simple, clear language
        Focus only on makeup and beauty information. Be concise and specific.`;

        const response = await fetch(`${API_URL}?key=${API_KEY}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: contextPrompt
                    }]
                }]
            })
        });

        const data = await response.json();
        
        // Remove loading indicator
        if (loadingDiv.parentNode) {
            chatMessages.removeChild(loadingDiv);
        }

        if (data.error) {
            console.error('API Response Error:', data.error);
            addMessage('Error: ' + data.error.message, 'bot', true);
            updateStatus('Error', true);
            return;
        }

        if (data.candidates && data.candidates[0] && data.candidates[0].content) {
            const aiResponse = data.candidates[0].content.parts[0].text;
            addMessage(aiResponse, 'bot');
            updateStatus('Ready to help');
        } else {
            throw new Error('Invalid response format');
        }

    } catch (error) {
        console.error('Request Error:', error);
        addMessage('An error occurred. Please try again.', 'bot', true);
        updateStatus('Error', true);
    }
}

// Clear chat history
function clearChat() {
    chatMessages.innerHTML = '';
    chatHistory = [];
    addMessage("Hello! I'm your AI Makeup Assistant. I can help you with makeup tips, product recommendations, and beauty advice. What would you like to know about makeup or skincare?", 'bot');
    updateStatus('Ready to help');
}

// Save chat history
function saveChat() {
    const chatData = JSON.stringify(chatHistory, null, 2);
    const blob = new Blob([chatData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `makeup-chat-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Event listeners
sendMessageBtn.addEventListener('click', async () => {
    const message = userInput.value.trim();
    if (message) {
        setInputState(true);
        userInput.value = '';
        await sendMessage(message);
        setInputState(false);
    }
});

userInput.addEventListener('keypress', async (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        const message = userInput.value.trim();
        if (message) {
            setInputState(true);
            userInput.value = '';
            await sendMessage(message);
            setInputState(false);
        }
    }
});

// Input state management
function setInputState(disabled) {
    userInput.disabled = disabled;
    sendMessageBtn.disabled = disabled;
    suggestionButtons.forEach(button => button.disabled = disabled);
}

// Suggestion buttons
suggestionButtons.forEach(button => {
    button.addEventListener('click', async () => {
        setInputState(true);
        await sendMessage(button.textContent.trim());
        setInputState(false);
    });
});

// Clear and Save chat buttons
clearChatBtn.addEventListener('click', clearChat);
saveChatBtn.addEventListener('click', saveChat);

// Initialize chat
document.addEventListener('DOMContentLoaded', () => {
    clearChat(); // This will add the welcome message
    testApiConnection();
});

// Skin Analysis Feature
document.addEventListener('DOMContentLoaded', () => {
    const uploadArea = document.querySelector('.upload-area');
    const fileInput = document.getElementById('file-input');
    const previewArea = document.querySelector('.preview-area');
    const previewImage = document.querySelector('#preview-image');
    const fileName = document.querySelector('.file-name');
    const analyzeBtn = document.querySelector('.analyze-btn');
    const chooseFileBtn = document.querySelector('.choose-file-btn');
    const analysisStatus = document.querySelector('.analysis-status');
    const resultsContainer = document.querySelector('.results-container');
    let selectedFile = null;

    // Handle drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = '#d23f77';
        uploadArea.style.backgroundColor = 'rgba(210, 63, 119, 0.05)';
    });

    uploadArea.addEventListener('dragleave', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'rgba(210, 63, 119, 0.3)';
        uploadArea.style.backgroundColor = 'rgba(248, 249, 250, 0.5)';
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'rgba(210, 63, 119, 0.3)';
        uploadArea.style.backgroundColor = 'rgba(248, 249, 250, 0.5)';
        
        const files = e.dataTransfer.files;
        if (files.length > 0 && files[0].type.startsWith('image/')) {
            handleFile(files[0]);
        } else {
            alert('Please upload an image file');
        }
    });

    // Handle file input change
    fileInput.addEventListener('change', handleFileSelect);

    // Handle choose file button click
    chooseFileBtn.addEventListener('click', () => {
        fileInput.click();
    });

    async function handleFileSelect(e) {
        const file = e.target.files[0];
        if (!file || !file.type.startsWith('image/')) {
            alert('Please select an image file');
            return;
        }

        selectedFile = file;
        showPreview(file);
        await analyzeImage(file);
    }

    function showPreview(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            previewImage.src = e.target.result;
            fileName.textContent = file.name;
            previewArea.style.display = 'block';
            analyzeBtn.style.display = 'flex';
            analysisStatus.style.display = 'none';
            resultsContainer.style.display = 'none';
        };
        reader.readAsDataURL(file);
    }

    async function analyzeImage(file) {
        try {
            // Convert image to base64
            const base64Image = await getBase64(file);
            const base64Data = base64Image.split(',')[1];

            // First, save the image to your backend
            const uploadResponse = await fetch('/api/upload', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    image: base64Data,
                    filename: file.name
                })
            });

            if (!uploadResponse.ok) {
                throw new Error('Failed to upload image');
            }

            // Then analyze with Google Vision API
            const visionResponse = await fetch('https://vision.googleapis.com/v1/images:annotate?key=' + API_KEY, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    requests: [{
                        image: {
                            content: base64Data
                        },
                        features: [
                            {
                                type: 'FACE_DETECTION',
                                maxResults: 1
                            },
                            {
                                type: 'IMAGE_PROPERTIES',
                                maxResults: 1
                            }
                        ]
                    }]
                })
            });

            const visionData = await visionResponse.json();

            if (visionData.error) {
                throw new Error(visionData.error.message);
            }

            // Process analysis results
            const analysis = processAnalysisResults(visionData);

            // Get product recommendations from your backend
            const recommendationsResponse = await fetch('/api/recommendations', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    skinType: analysis.skinType,
                    concerns: analysis.concerns
                })
            });

            const recommendationsData = await recommendationsResponse.json();

            // Display results
            displayResults(analysis, recommendationsData);

        } catch (error) {
            console.error('Error analyzing image:', error);
            alert('Sorry, there was an error analyzing your image. Please try again.');
        } finally {
            analysisStatus.style.display = 'none';
        }
    }

    function processAnalysisResults(data) {
        const analysis = {
            skinType: 'unknown',
            concerns: [],
            features: {}
        };

        try {
            const faceAnnotation = data.responses[0].faceAnnotations?.[0];
            const imageProperties = data.responses[0].imageProperties;

            if (imageProperties?.dominantColors?.colors) {
                const mainColor = imageProperties.dominantColors.colors[0].color;
                const brightness = (mainColor.red + mainColor.green + mainColor.blue) / 3;

                // Determine skin type based on color analysis
                if (brightness > 0.7) analysis.skinType = 'fair';
                else if (brightness > 0.5) analysis.skinType = 'medium';
                else analysis.skinType = 'dark';

                // Analyze undertone
                const redGreenRatio = mainColor.red / mainColor.green;
                analysis.features.undertone = redGreenRatio > 1.2 ? 'warm' : 'cool';
            }

            if (faceAnnotation) {
                // Analyze skin concerns
                if (faceAnnotation.underExposedLikelihood === 'VERY_LIKELY') {
                    analysis.concerns.push('uneven skin tone');
                }
                if (faceAnnotation.blurredLikelihood === 'VERY_LIKELY') {
                    analysis.concerns.push('texture concerns');
                }
                
                // Additional features
                analysis.features.confidence = faceAnnotation.detectionConfidence;
                analysis.features.joyLikelihood = faceAnnotation.joyLikelihood;
            }
        } catch (error) {
            console.error('Error processing analysis:', error);
        }

        return analysis;
    }

    function displayResults(analysis, recommendations) {
        // Display skin analysis
        const skinDetails = document.getElementById('skin-details');
        skinDetails.innerHTML = `
            <div class="analysis-item">
                <h4>Skin Type</h4>
                <p>${capitalizeFirst(analysis.skinType)} skin with ${analysis.features.undertone} undertone</p>
            </div>
            ${analysis.concerns.length > 0 ? `
                <div class="analysis-item">
                    <h4>Concerns</h4>
                    <p>${analysis.concerns.map(capitalizeFirst).join(', ')}</p>
                </div>
            ` : ''}
        `;

        // Display product recommendations
        const productList = document.getElementById('product-list');
        productList.innerHTML = recommendations.products.map(product => `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}" class="product-image">
                <div class="product-info">
                    <h4>${product.name}</h4>
                    <p>${product.description}</p>
                    <p class="price">$${product.price}</p>
                </div>
            </div>
        `).join('');

        // Display skincare routine
        const routineSteps = document.getElementById('routine-steps');
        routineSteps.innerHTML = recommendations.routine.map((step, index) => `
            <div class="routine-step">
                <div class="step-number">${index + 1}</div>
                <div class="step-content">
                    <h4>${step.title}</h4>
                    <p>${step.description}</p>
                </div>
            </div>
        `).join('');

        // Show results
        resultsContainer.style.display = 'block';
    }

    function getBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }

    function capitalizeFirst(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
}); 